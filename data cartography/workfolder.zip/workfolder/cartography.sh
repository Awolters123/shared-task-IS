#!/usr/bin/env bash

mapping () {
    MODEL=$1
    DATA=$2

    python -m cartography.selection.train_dy_filtering \
        --plot \
        --model $MODEL \
        --model_dir carto_shared_data/logits/$DATA/$MODEL \
        --plots_dir carto_shared_data/outputs/maps/$DATA
}


data_output () {
    MODEL=$1
    DATA=$2
    METRIC=$3

    if [ "$METRIC" == "hard-to-learn" ]; then
        METRIC_PARAM="confidence"
    elif [ "$METRIC" == "ambiguous" ]; then
        METRIC_PARAM="variability"
    fi

    if [ "$METRIC" == "easy-to-learn" ]; then
    python -m cartography.selection.train_dy_filtering \
        --filter \
        --model $MODEL \
        --metric "confidence" --worst \
        --model_dir carto_shared_data/logits/$DATA/$MODEL \
        --filtering_output_dir carto_shared_data/outputs/data/$DATA/$MODEL/$METRIC \
        --data_dir carto_shared_data/datafiles_for_cartography/$DATA/$MODEL
    else
    python -m cartography.selection.train_dy_filtering \
        --filter \
        --model $MODEL \
        --metric $METRIC_PARAM \
        --model_dir carto_shared_data/logits/$DATA/$MODEL \
        --filtering_output_dir carto_shared_data/outputs/data/$DATA/$MODEL/$METRIC/ \
        --data_dir carto_shared_data/datafiles_for_cartography/$DATA/$MODEL
    fi
}


cartography () {
    MODEL=$1
    DATA=$2

    # $MODEL $DATA map
    mapping $MODEL $DATA

    # $MODEL $DATA output data, in order: hard-to-learn -> ambiguous -> easy-to-learn
    data_output $MODEL $DATA "hard-to-learn"
    data_output $MODEL $DATA "ambiguous"
    data_output $MODEL $DATA "easy-to-learn"
}


################
### HateBERT ###
################

# HateBERT SemEval, Exist, and shuffle_semeval-exist
    cartography "hatebert" "semeval"
    cartography "hatebert" "exist"
    cartography "hatebert" "shuffle_semeval-exist"


###############
### DeBERTa ###
###############

# DeBERTa SemEval, Exist, and shuffle_semeval-exist
    cartography "deberta" "semeval"
    cartography "deberta" "exist"
    cartography "deberta" "shuffle_semeval-exist"
